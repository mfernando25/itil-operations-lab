# ITIL Operations Lab · v0.2.0

Laboratorio académico de operaciones TI e ITIL 4 para investigar siete eventos de un portal universitario. La solución genera datos, historiales y evidencias de escenario al momento de activarlos; no necesita esperar cinco días de recolección.

## Inicio rápido en Windows

```powershell
git clone https://github.com/mfernando25/itil-operations-lab.git
cd itil-operations-lab
.\scripts\setup_windows.ps1
.\scripts\start_lab.ps1
```

- **Vista de estudiantes:** http://127.0.0.1:8000
- **Panel privado del docente:** http://127.0.0.1:8000/instructor

Mantén abierta la ventana de PowerShell durante la sesión. Detén el servidor con `Ctrl+C`.

## Requisitos

- Windows 10/11 (probado como entorno principal), Python 3.10 o superior y Git en PATH.
- La versión local no requiere Docker ni cuentas personales de estudiantes.
- Para los grupos 1 y 2 se necesita acceso al repositorio GitHub y a su pestaña Actions.

## Los siete grupos

| Grupo | Evento | Mecanismo de demostración |
|---|---|---|
| 1 | Fallo en pruebas automatizadas | GitHub Actions ejecuta una prueba de regresión deliberadamente fallida y publica logs como artefacto. |
| 2 | Fallo durante el workflow | GitHub Actions detiene la ejecución durante una validación de configuración, antes de iniciar tests. |
| 3 | Sincronización Git | Se construye un repositorio local aislado con rama remota y local divergentes; el pull produce un conflicto reproducible. |
| 4 | CPU anormal | Se generan diez muestras distribuidas en cinco días con CPU, solicitudes/minuto y latencia correlacionadas. |
| 5 | Crecimiento de almacenamiento | Se generan cinco puntos de capacidad/espacio disponible y desglose de logs y respaldos en un volumen lógico de 10 GB. |
| 6 | Incompatibilidad entre servicios | El proveedor cambia campos del contrato y el consumidor no puede completar el perfil. |
| 7 | Información desactualizada | La escritura se confirma en el registro principal, mientras la caché conserva el estado anterior. |

## Historiales de cinco días: cómo funcionan

G4 y G5 crean sus series históricas al pulsar **Preparar / activar** en el panel docente. Las marcas temporales se distribuyen en los cinco días anteriores a la activación; la evidencia queda disponible inmediatamente.

Esos datos son **datos generados para el escenario**, no registros históricos reales de la laptop. Las métricas reales del equipo (CPU, memoria y disco) se siguen registrando aparte, cada 60 segundos por defecto. La interfaz de estudiantes no presenta etiquetas técnicas sobre el origen de los puntos. El panel docente conserva la distinción.

G5 modela un volumen lógico de 10 GB. Solo se escribe un pequeño archivo descriptivo; no se crean archivos de varios gigabytes ni se llena el disco real.

## Flujo del docente

1. Abre `/instructor` en tu laptop.
2. Pulsa **Preparar / activar** para el grupo asignado. La activación genera el evento y, cuando corresponde, el dataset o repositorio de práctica.
3. Abre **Preparar evidencia para correo**, selecciona grupo y paquete y descarga el Markdown.
4. Envía primero la notificación inicial (paquete 0). Entrega los paquetes 1, 2 y 3 según las solicitudes justificadas de los equipos.
5. Consulta **Notas internas** solo desde el panel docente. No compartas esa consola.

Cada grupo dispone de una notificación inicial y tres paquetes adicionales. Los paquetes son materiales de apoyo para la investigación; el estudiante debe explicar qué información necesita y por qué.

## GitHub Actions: grupos 1 y 2

En el panel docente usa el enlace a Actions:

- `G1 - Fallo de pruebas`: ejecuta una prueba de regresión que falla. El workflow guarda logs, resultado JUnit, historial de commits y archivos modificados en el artefacto `G1-evidencia-ejecucion`.
- `G2 - Fallo de prevalidación`: detiene el flujo antes de instalar dependencias y ejecutar pruebas. Guarda la salida y configuración del workflow en `G2-evidencia-prevalidacion`.

Descarga cada artefacto desde la ejecución correspondiente en GitHub Actions. La CI normal de `main` ejecuta la suite del proyecto y debe permanecer aprobada.

## Grupo 3: repositorio de práctica aislado

Al activar G3 se crea `lab_data/scenarios/g3/student-workspace`, un repositorio local de práctica. No modifica el repositorio Git de este proyecto. Los archivos `evidence/` que contiene documentan el rechazo, el estado local y el estado remoto. Git debe estar instalado y disponible en PATH.

## Grupos 6 y 7: comprobación funcional

En la vista de estudiantes:

- La consulta de perfil permite observar la degradación después de activar G6.
- La consulta de matrícula permite comparar el estado disponible antes y después de activar G7.

En el panel docente se puede reiniciar cada escenario. En G7, el botón de sincronización del portal actualiza la caché después de que el equipo haya investigado el problema.

## Arquitectura y alcance

La versión local es una aplicación ligera Python con límites lógicos separados para estudiantes, cursos y matrículas, un servidor HTTP local y SQLite. Esta versión prioriza instalación simple y reproducibilidad para la sesión en aula; los límites de servicio se simulan dentro de un mismo proceso y **todavía no son tres contenedores FastAPI independientes**. No se debe presentar como una arquitectura de microservicios desplegada en Docker.

## Pruebas y reinicio

```powershell
python -m pytest -q
python scripts/reset_lab.py
```

El reinicio borra la base local y los repositorios/datasets generados. No modifica los commits del repositorio GitHub. Después de reiniciar, activa nuevamente los grupos para regenerar sus evidencias.

## Seguridad

- El servidor se enlaza a `127.0.0.1`; no lo expongas a la red local.
- No uses datos reales de estudiantes ni secretos en el repositorio.
- La ruta `/instructor` y sus endpoints son una consola local sin autenticación: no compartas esa URL ni ejecutes el servidor en una interfaz de red pública.
- El archivo `INSTRUCTOR_RUNBOOK_PRIVATE.md` es para el docente y no debe subirse al repositorio público.
